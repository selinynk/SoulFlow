﻿namespace SoulFlow.Models
{
    public enum ParticipationStatus
    {
        Bekleniyor,
        Katildi,
        Gelmedi,
        IptalEtti
    }
}